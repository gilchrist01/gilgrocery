export class Login{

    constructor(public Username:any, public password:any)
    {

    }
}