export class User{

    constructor(public name:any, public mobilenumber:any )
    {
        
    }
}